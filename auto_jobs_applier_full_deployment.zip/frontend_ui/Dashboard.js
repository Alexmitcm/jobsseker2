
import React from 'react';

function Dashboard() {
    return (
        <div style={{ textAlign: 'center', padding: '20px' }}>
            <h2>Dashboard</h2>
            <p>Notifications: 5</p>
            <p>Applications Submitted: 10</p>
            <nav>
                <a href="/notifications" style={{ margin: '10px' }}>Manage Notifications</a>
                <a href="/applications" style={{ margin: '10px' }}>Manage Applications</a>
            </nav>
        </div>
    );
}

export default Dashboard;
