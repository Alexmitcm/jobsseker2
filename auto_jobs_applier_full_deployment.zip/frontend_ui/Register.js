
import React, { useState } from 'react';

function Register() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        alert(`Registered as: ${name}, Email: ${email}`);
    };

    return (
        <div style={{ textAlign: 'center', padding: '20px' }}>
            <h2>Register</h2>
            <form onSubmit={handleSubmit} style={{ display: 'inline-block', textAlign: 'left' }}>
                <label>Name:</label><br />
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} required /><br /><br />
                <label>Email:</label><br />
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /><br /><br />
                <button type="submit">Register</button>
            </form>
        </div>
    );
}

export default Register;
