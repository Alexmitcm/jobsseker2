
import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
    return (
        <div style={{ textAlign: 'center', padding: '20px' }}>
            <h1>Welcome to Auto Jobs Applier</h1>
            <nav style={{ marginTop: '20px' }}>
                <Link to="/login" style={{ margin: '10px' }}>Login</Link>
                <Link to="/register" style={{ margin: '10px' }}>Register</Link>
                <Link to="/dashboard" style={{ margin: '10px' }}>Dashboard</Link>
                <Link to="/automation" style={{ margin: '10px' }}>Automation</Link>
            </nav>
        </div>
    );
}

export default Home;
