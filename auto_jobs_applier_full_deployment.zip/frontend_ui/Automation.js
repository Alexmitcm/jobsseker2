
import React, { useState } from 'react';

function Automation() {
    const [status, setStatus] = useState('Idle');

    const handleAutomation = () => {
        setStatus('Running...');
        setTimeout(() => {
            setStatus('Completed!');
        }, 3000);
    };

    return (
        <div style={{ textAlign: 'center', padding: '20px' }}>
            <h2>Automation</h2>
            <button onClick={handleAutomation}>Start Automation</button>
            <p>Status: {status}</p>
        </div>
    );
}

export default Automation;
